// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports","./scrim"],function(a,b){const c=b.defineCustomElement;a.CalciteScrim=b.Scrim;a.defineCustomElement=c;Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});