// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){const c=new WeakMap,d=new WeakMap;b.componentLoaded=function(a){return d.get(a)};b.setComponentLoaded=function(a){c.get(a)()};b.setUpLoadableComponent=function(a){d.set(a,new Promise(e=>c.set(a,e)))}});