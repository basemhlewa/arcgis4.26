// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports"],function(c){function e(){const a=new Float32Array(4);a[3]=1;return a}function f(a){const b=new Float32Array(4);b[0]=a[0];b[1]=a[1];b[2]=a[2];b[3]=a[3];return b}function g(a,b,k,l){const d=new Float32Array(4);d[0]=a;d[1]=b;d[2]=k;d[3]=l;return d}function h(a,b){return new Float32Array(a,b,4)}const m=Object.freeze(Object.defineProperty({__proto__:null,clone:f,create:e,createView:h,fromValues:g},Symbol.toStringTag,{value:"Module"}));c.clone=f;c.create=e;c.createView=h;c.fromValues=
g;c.quatf32=m});