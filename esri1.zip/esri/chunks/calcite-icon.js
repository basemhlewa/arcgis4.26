// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports","./icon"],function(a,b){const c=b.defineCustomElement;a.CalciteIcon=b.Icon;a.defineCustomElement=c;Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});