// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){function c(){return[0,0,0,1]}function e(a){return[a[0],a[1],a[2],a[3]]}function f(a,d,k,l){return[a,d,k,l]}function g(a,d){return new Float64Array(a,d,4)}const h=c(),m=Object.freeze(Object.defineProperty({__proto__:null,IDENTITY:h,clone:e,create:c,createView:g,fromValues:f},Symbol.toStringTag,{value:"Module"}));b.IDENTITY=h;b.clone=e;b.create=c;b.createView=g;b.fromValues=f;b.quatf64=m});