// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports","./index"],function(b,c){b.Heading=(a,d)=>{const e=a.level?`h${a.level}`:"div";delete a.level;return c.h(e,{...a},d)}});