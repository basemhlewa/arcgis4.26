// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define("exports ../views/3d/support/engineContent/marker ../views/3d/webgl-engine/core/shaderLibrary/ForwardLinearDepth.glsl ../views/3d/webgl-engine/core/shaderLibrary/ShaderOutput ../views/3d/webgl-engine/core/shaderLibrary/Slice.glsl ../views/3d/webgl-engine/core/shaderLibrary/attributes/RibbonVertexPosition.glsl ../views/3d/webgl-engine/core/shaderLibrary/output/OutputDepth.glsl ../views/3d/webgl-engine/core/shaderLibrary/shading/MarkerSizing.glsl ../views/3d/webgl-engine/core/shaderLibrary/shading/MultipassTerrainTest.glsl ../views/3d/webgl-engine/core/shaderLibrary/util/AlphaCutoff ../views/3d/webgl-engine/core/shaderLibrary/util/ColorConversion.glsl ../views/3d/webgl-engine/core/shaderLibrary/util/RgbaFloatEncoding.glsl ../views/3d/webgl-engine/core/shaderLibrary/util/View.glsl ../views/3d/webgl-engine/core/shaderModules/Float2PassUniform ../views/3d/webgl-engine/core/shaderModules/Float4PassUniform ../views/3d/webgl-engine/core/shaderModules/FloatPassUniform ../views/3d/webgl-engine/core/shaderModules/interfaces ../views/3d/webgl-engine/core/shaderModules/Matrix4PassUniform ../views/3d/webgl-engine/core/shaderModules/ShaderBuilder ../views/3d/webgl-engine/core/shaderModules/Texture2DPassUniform ../views/3d/webgl-engine/lib/TransparencyPassType ../views/3d/webgl-engine/lib/VertexAttribute ../views/3d/webgl-engine/shaders/LineMarkerTechniqueConfiguration".split(" "),
function(q,l,r,e,x,y,z,A,B,C,D,E,t,F,u,v,c,G,H,I,J,m,n){function w(a){const b=new H.ShaderBuilder,p=a.hasMultipassTerrain&&(a.output===e.ShaderOutput.Color||a.output===e.ShaderOutput.Alpha),g=a.space===n.LineMarkerSpace.World;a.hasTip&&g&&b.extensions.add("GL_OES_standard_derivatives");b.include(y.RibbonVertexPosition,a);b.include(A.MarkerSizing,a);a.output===e.ShaderOutput.Depth&&b.include(z.OutputDepth,a);const {vertex:d,fragment:k}=b;k.include(E.RgbaFloatEncoding);t.addProjViewLocalOrigin(d,a);
b.attributes.add(m.VertexAttribute.POSITION,"vec3");b.attributes.add(m.VertexAttribute.UV0,"vec2");b.attributes.add(m.VertexAttribute.AUXPOS1,"vec3");b.varyings.add("vColor","vec4");b.varyings.add("vpos","vec3");b.varyings.add("vUV","vec2");b.varyings.add("vSize","float");r.addLinearDepth(b);p&&b.varyings.add("depth","float");a.hasTip&&b.varyings.add("vLineWidth","float");d.uniforms.add([new F.Float2PassUniform("nearFar",(h,f)=>f.camera.nearFar),new u.Float4PassUniform("viewport",(h,f)=>f.camera.fullViewport)]);
d.code.add(c.glsl`vec4 projectAndScale(vec4 pos) {
vec4 posNdc = proj * pos;
posNdc.xy *= viewport.zw / posNdc.w;
return posNdc;
}`);d.code.add(c.glsl`void clip(vec4 pos, inout vec4 prev) {
float vnp = nearFar[0] * 0.99;
if (prev.z > -nearFar[0]) {
float interpolation = (-vnp - pos.z) / (prev.z - pos.z);
prev = mix(pos, prev, interpolation);
}
}`);g?(b.attributes.add(m.VertexAttribute.NORMAL,"vec3"),t.addViewNormal(d),d.constants.add("tiltThreshold","float",.7),d.code.add(c.glsl`vec3 perpendicular(vec3 v) {
vec3 n = (viewNormal * vec4(normal.xyz, 1.0)).xyz;
vec3 n2 = cross(v, n);
vec3 forward = vec3(0.0, 0.0, 1.0);
float tiltDot = dot(forward, n);
return abs(tiltDot) < tiltThreshold ? n : n2;
}`)):d.code.add(c.glsl`vec2 perpendicular(vec2 v) {
return vec2(v.y, -v.x);
}`);d.code.add(c.glsl`
      #define vecN ${g?"vec3":"vec2"}

      vecN normalizedSegment(vecN pos, vecN prev) {
        vecN segment = pos - prev;
        float segmentLen = length(segment);

        // normalize or zero if too short
        return (segmentLen > 0.001) ? segment / segmentLen : ${g?"vec3(0.0, 0.0, 0.0)":"vec2(0.0, 0.0)"};
      }

      vecN displace(vecN pos, vecN prev, float displacementLen) {
        vecN segment = normalizedSegment(pos, prev);

        vecN displacementDirU = perpendicular(segment);
        vecN displacementDirV = segment;

        ${a.anchor===n.LineMarkerAnchor.Tip?"pos -\x3d 0.5 * displacementLen * displacementDirV;":""}

        return pos + displacementLen * (uv0.x * displacementDirU + uv0.y * displacementDirV);
      }
    `);a.space===n.LineMarkerSpace.Screen&&(d.uniforms.add(new G.Matrix4PassUniform("inverseProjectionMatrix",(h,f)=>f.camera.inverseProjectionMatrix)),d.code.add(c.glsl`vec3 inverseProject(vec4 posScreen) {
posScreen.xy = (posScreen.xy / viewport.zw) * posScreen.w;
return (inverseProjectionMatrix * posScreen).xyz;
}`),d.code.add(c.glsl`bool rayIntersectPlane(vec3 rayDir, vec3 planeOrigin, vec3 planeNormal, out vec3 intersection) {
float cos = dot(rayDir, planeNormal);
float t = dot(planeOrigin, planeNormal) / cos;
intersection = t * rayDir;
return abs(cos) > 0.001 && t > 0.0;
}`),d.uniforms.add(new v.FloatPassUniform("perScreenPixelRatio",(h,f)=>f.camera.perScreenPixelRatio)),d.code.add(c.glsl`
      vec4 toFront(vec4 displacedPosScreen, vec3 posLeft, vec3 posRight, vec3 prev, float lineWidth) {
        // Project displaced position back to camera space
        vec3 displacedPos = inverseProject(displacedPosScreen);

        // Calculate the plane that we want the marker to lie in. Note that this will always be an approximation since ribbon lines are generally
        // not planar and we do not know the actual position of the displaced prev vertices (they are offset in screen space, too).
        vec3 planeNormal = normalize(cross(posLeft - posRight, posLeft - prev));
        vec3 planeOrigin = posLeft;

        ${a.hasCap?"\n                if(prev.z \x3e posLeft.z) {\n                  vec2 diff \x3d posLeft.xy - posRight.xy;\n                  planeOrigin.xy +\x3d perpendicular(diff) / 2.0;\n                }\n              ":""};

        // Move the plane towards the camera by a margin dependent on the line width (approximated in world space). This tolerance corrects for the
        // non-planarity in most cases, but sharp joins can place the prev vertices at arbitrary positions so markers can still clip.
        float offset = lineWidth * perScreenPixelRatio;
        planeOrigin *= (1.0 - offset);

        // Intersect camera ray with the plane and make sure it is within clip space
        vec3 rayDir = normalize(displacedPos);
        vec3 intersection;
        if (rayIntersectPlane(rayDir, planeOrigin, planeNormal, intersection) && intersection.z < -nearFar[0] && intersection.z > -nearFar[1]) {
          return vec4(intersection.xyz, 1.0);
        }

        // Fallback: use depth of pos or prev, whichever is closer to the camera
        float minDepth = planeOrigin.z > prev.z ? length(planeOrigin) : length(prev);
        displacedPos *= minDepth / length(displacedPos);
        return vec4(displacedPos.xyz, 1.0);
      }
  `));d.uniforms.add(new v.FloatPassUniform("pixelRatio",(h,f)=>f.camera.pixelRatio));r.addCalculateLinearDepth(b);d.code.add(c.glsl`void main(void) {
if (uv0.y == 0.0) {
gl_Position = vec4(1e038, 1e038, 1e038, 1.0);
}
else {
float lineWidth = getLineWidth();
float screenMarkerSize = getScreenMarkerSize();
vec4 pos  = view * vec4(position.xyz, 1.0);
vec4 prev = view * vec4(auxpos1.xyz, 1.0);
clip(pos, prev);`);g?(a.hideOnShortSegments&&d.code.add(c.glsl`if (areWorldMarkersHidden(pos, prev)) {
gl_Position = vec4(1e038, 1e038, 1e038, 1.0);
return;
}`),d.code.add(c.glsl`pos.xyz = displace(pos.xyz, prev.xyz, getWorldMarkerSize(pos));
vec4 displacedPosScreen = projectAndScale(pos);`)):(d.code.add(c.glsl`vec4 posScreen = projectAndScale(pos);
vec4 prevScreen = projectAndScale(prev);
vec4 displacedPosScreen = posScreen;
displacedPosScreen.xy = displace(posScreen.xy, prevScreen.xy, screenMarkerSize);`),a.space===n.LineMarkerSpace.Screen&&d.code.add(c.glsl`vec2 displacementDirU = perpendicular(normalizedSegment(posScreen.xy, prevScreen.xy));
vec3 lineRight = inverseProject(posScreen + lineWidth * vec4(displacementDirU.xy, 0.0, 0.0));
vec3 lineLeft = pos.xyz + (pos.xyz - lineRight);
pos = toFront(displacedPosScreen, lineLeft, lineRight, prev.xyz, lineWidth);
displacedPosScreen = projectAndScale(pos);`));d.code.add(c.glsl`
        ${p?"depth \x3d pos.z;":""}
        linearDepth = calculateLinearDepth(nearFar,pos.z);

        // Convert back into NDC
        displacedPosScreen.xy = (displacedPosScreen.xy / viewport.zw) * displacedPosScreen.w;

        // Convert texture coordinate into [0,1]
        vUV = (uv0 + 1.0) / 2.0;

        ${g?"":"vUV *\x3d displacedPosScreen.w;"}

        ${a.hasTip?"vLineWidth \x3d lineWidth;":""}

        vSize = screenMarkerSize;
        vColor = getColor();

        // Use camera space for slicing
        vpos = pos.xyz;

        gl_Position = displacedPosScreen;
      }
    }
  `);p&&b.include(B.multipassTerrainTest,a);b.include(x.SliceDraw,a);k.uniforms.add([new u.Float4PassUniform("intrinsicColor",h=>h.color),new I.Texture2DPassUniform("tex",h=>h.texture)]);k.include(D.ColorConversion);b.constants.add("texelSize","float",1/l.MARKER_TEXTURE_SIZE);k.code.add(c.glsl`float markerAlpha(vec2 samplePos) {
samplePos += vec2(0.5, -0.5) * texelSize;
float sdf = rgba2float(texture2D(tex, samplePos)) - 0.5;
float distance = sdf * vSize;
distance -= 0.5;
return clamp(0.5 - distance, 0.0, 1.0);
}`);a.hasTip&&(b.constants.add("relativeMarkerSize","float",l.MARKER_SYMBOL_SIZE/l.MARKER_TEXTURE_SIZE),b.constants.add("relativeTipLineWidth","float",l.MARKER_TIP_THICKNESS_FACTOR),k.code.add(c.glsl`
    float tipAlpha(vec2 samplePos) {
      // Convert coordinates s.t. they are in pixels and relative to the tip of an arrow marker
      samplePos -= vec2(0.5, 0.5 + 0.5 * relativeMarkerSize);
      samplePos *= vSize;

      float halfMarkerSize = 0.5 * relativeMarkerSize * vSize;
      float halfTipLineWidth = 0.5 * max(1.0, relativeTipLineWidth * vLineWidth);

      ${g?"halfTipLineWidth *\x3d fwidth(samplePos.y);":""}

      float distance = max(abs(samplePos.x) - halfMarkerSize, abs(samplePos.y) - halfTipLineWidth);
      return clamp(0.5 - distance, 0.0, 1.0);
    }
  `));b.constants.add("symbolAlphaCutoff","float",C.symbolAlphaCutoff);k.code.add(c.glsl`
  void main() {
    discardBySlice(vpos);
    ${p?"terrainDepthTest(gl_FragCoord, depth);":""}

    vec4 finalColor = intrinsicColor * vColor;

    ${g?"vec2 samplePos \x3d vUV;":"vec2 samplePos \x3d vUV * gl_FragCoord.w;"}

    ${a.hasTip?"finalColor.a *\x3d max(markerAlpha(samplePos), tipAlpha(samplePos));":"finalColor.a *\x3d markerAlpha(samplePos);"}

    ${a.output===e.ShaderOutput.ObjectAndLayerIdColor?c.glsl`finalColor.a = 1.0;`:""}

    if (finalColor.a < symbolAlphaCutoff) {
      discard;
    }

    ${a.output===e.ShaderOutput.Alpha?c.glsl`gl_FragColor = vec4(finalColor.a);`:""}
    ${a.output===e.ShaderOutput.Color?c.glsl`gl_FragColor = highlightSlice(finalColor, vpos);`:""}
    ${a.output===e.ShaderOutput.Color&&a.transparencyPassType===J.TransparencyPassType.Color?"gl_FragColor \x3d premultiplyAlpha(gl_FragColor);":""}
    ${a.output===e.ShaderOutput.Highlight?c.glsl`gl_FragColor = vec4(1.0);`:""}
    ${a.output===e.ShaderOutput.Depth?c.glsl`outputDepth(linearDepth);`:""}
  }
  `);return b}const K=Object.freeze(Object.defineProperty({__proto__:null,build:w},Symbol.toStringTag,{value:"Module"}));q.LineMarker=K;q.build=w});