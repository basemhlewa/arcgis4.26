// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports"],function(a){a.isActivationKey=function(b){return"Enter"===b||" "===b};a.numberKeys="0123456789".split("")});