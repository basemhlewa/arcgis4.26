// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports"],function(a){a.isUpdating=function(b){return"updating"===b};a.unwrapUpdating=function(b){return"updating"===b?null:b};a.updating="updating";Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});