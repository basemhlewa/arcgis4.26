// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports","../multiOriginJSONSupportUtils"],function(d,f){d.updateOrigins=function(a){a&&a.writtenProperties&&a.writtenProperties.forEach(({target:b,propName:e,newOrigin:c})=>{f.isMultiOriginJSONMixin(b)&&c&&b.originOf(e)!==c&&b.updateOrigin(e,c)})};Object.defineProperty(d,Symbol.toStringTag,{value:"Module"})});