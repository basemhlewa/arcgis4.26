// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports"],function(a){a.writeNonEmptyCollectionPolicy=function(b){return{enabled:!!b?.length}};Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});