// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports","../../arrayUtils"],function(a,c){let f=function(){function b(d,e){this._observers=d;this._observer=e}b.prototype.remove=function(){c.remove(this._observers,this._observer)};return b}();a.ObservationHandle=f;Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});