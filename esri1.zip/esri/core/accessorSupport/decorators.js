// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define("exports ./decorators/aliasOf ./decorators/cast ./decorators/enumeration ./decorators/property ./decorators/reader ./decorators/shared ./decorators/subclass ./decorators/writer".split(" "),function(a,d,e,f,b,g,h,c,k){a.aliasOf=d.aliasOf;a.cast=e.cast;a.enumeration=f.enumeration;a.ensureRange=b.ensureRange;a.property=b.property;a.propertyJSONMeta=b.propertyJSONMeta;a.reader=g.reader;a.shared=h.shared;a.finalizeClass=c.finalizeClass;a.subclass=c.subclass;a.writer=k.writer;Object.defineProperty(a,
Symbol.toStringTag,{value:"Module"})});