// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports","./property"],function(a,d){a.aliasOf=function(b,c){return d.property({aliasOf:c?{...c,source:b}:b})};Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});