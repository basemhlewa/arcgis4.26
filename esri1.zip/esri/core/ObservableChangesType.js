// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){b.ObservableChangesType=void 0;var a=b.ObservableChangesType||(b.ObservableChangesType={});a[a.ADD=1]="ADD";a[a.REMOVE=2]="REMOVE";a[a.MOVE=4]="MOVE";Object.defineProperty(b,Symbol.toStringTag,{value:"Module"})});