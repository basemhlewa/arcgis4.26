// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports"],function(a){a.DiagnosticSeverity=void 0;var b=a.DiagnosticSeverity||(a.DiagnosticSeverity={});b.Error="Error";b.Warning="Warning";Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});