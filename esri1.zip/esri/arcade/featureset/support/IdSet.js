// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(function(){return function(a,b,c,d){this._lastFetchedIndex=0;this._ordered=!1;this.pagesDefinition=null;this._candidates=a;this._known=b;this._ordered=c;this.pagesDefinition=d}});