// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports"],function(a){a.FeatureSetQueryInterceptor=function(b,c){this.preLayerQueryCallback=b;this.preRequestCallback=c;this.preLayerQueryCallback||(this.preLayerQueryCallback=d=>{});this.preRequestCallback||(this.preLayerQueryCallback=d=>{})};Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});