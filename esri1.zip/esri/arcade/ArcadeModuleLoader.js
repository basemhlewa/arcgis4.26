// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){let e=function(){function c(a,d){this._moduleSingletons=a;this._syntaxModules=d}c.prototype.loadLibrary=function(a){return null==this._syntaxModules?null:(a=this._syntaxModules[a.toLowerCase()])?{syntax:a.script,uri:a.uri}:null};return c}();b.ArcadeModuleLoader=e;Object.defineProperty(b,Symbol.toStringTag,{value:"Module"})});