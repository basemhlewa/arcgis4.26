// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.26/esri/copyright.txt for details.
//>>built
define(["exports"],function(a){a.LengthDimensionMeasureType=void 0;var b=a.LengthDimensionMeasureType||(a.LengthDimensionMeasureType={});b.Horizontal="horizontal";b.Vertical="vertical";b.Direct="direct";a.lengthDimensionMeasureType=[a.LengthDimensionMeasureType.Horizontal,a.LengthDimensionMeasureType.Vertical,a.LengthDimensionMeasureType.Direct];Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});